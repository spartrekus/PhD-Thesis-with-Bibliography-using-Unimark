
1) Compile unimark.c

2) Convert MRK to TEX

3) Make all


